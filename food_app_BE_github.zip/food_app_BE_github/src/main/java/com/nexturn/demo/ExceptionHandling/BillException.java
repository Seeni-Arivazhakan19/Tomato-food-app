package com.nexturn.demo.ExceptionHandling;

public class BillException extends Exception{
	

	public BillException(String msg) {
		super(msg);
	}

}
