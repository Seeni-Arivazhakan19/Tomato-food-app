package com.nexturn.demo.ExceptionHandling;

public class RestaurantException extends Exception {
   
	public RestaurantException(){
		
	}
	
	public RestaurantException(String msg) {
		super(msg);
	}

}
