package com.nexturn.demo.ExceptionHandling;

public class OrderDetailsException extends Exception {
	

	
	public OrderDetailsException(String msg) {
		super(msg);
	}

}
