package com.nexturn.demo.ExceptionHandling;

public class MenuException extends Exception {

//public MenuException(){
//		
//	}
	
	public MenuException(String msg) {
		super(msg);
	}

	
}
