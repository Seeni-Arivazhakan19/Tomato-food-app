package com.nexturn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexturnCapstoneProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexturnCapstoneProjectApplication.class, args);
		System.out.println("it worksssss");
		
	}

}
