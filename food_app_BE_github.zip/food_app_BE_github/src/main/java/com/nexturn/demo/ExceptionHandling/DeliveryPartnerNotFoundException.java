package com.nexturn.demo.ExceptionHandling;

public class DeliveryPartnerNotFoundException extends Exception{
	
	public DeliveryPartnerNotFoundException() {
		
	}
	
	public DeliveryPartnerNotFoundException(String msg) {
		super(msg);
	}


}
