package com.nexturn.demo.ExceptionHandling;

public class FoodCartException extends Exception {
	

	
	public FoodCartException(String msg) {
		super(msg);
	}

}
