# Food_Delivery_Springboot and ReactJS

Online Food Delivery is an online application. where the customers get to search for the restautant and then get the menu and then order the food of 
their choice. 
These ordered food can be added to the food cart then checkout and get the order delivered within a specified time.

## Backend Tools 

Programming Language-> Java

Framework-> SpringBoot

DataBase-> MYSQL

Application to run on-> Spring Tool Suite(STS)

To test the results or the flow of the data PostMan is used.

## Front End
FrameWork-> React js

Scripting langugae-> Java Script

Application tool-> Vs Code

## In the command line promt

To create a react vite app-> npm create vite [app-name]

change directory-> cd [app-name]

npm install

to open vs code -> code .

To run the app in the Vs Code terminal-> npm run dev.

